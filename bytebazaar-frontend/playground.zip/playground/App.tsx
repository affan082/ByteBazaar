// import React from 'react';

import AddToCart from "../src/components/add-to-cart/AddToCart";
import "bootstrap/dist/css/bootstrap.css";
import "../public/css/global-css.scss";
import QueryableCustomCarousel from "../src/components/carousel/QueryableCustomCarousel";
import ProductCarouselTemplate1 from "../src/templates/ProductCarouselTemplate1";
import {ToastContainer} from "react-toastify";
function App() {
    return (
        <div>
            {/*<AddToCart id={"test_id"} label={"Add To Cart"} />*/}
            {/*<AddToCart id={"test_id_2"} label={"Add To Cart"} />*/}
            <QueryableCustomCarousel
                TemplateComponent={ProductCarouselTemplate1}
                query={{limit:4}}

             />
            <ToastContainer autoClose={false} />
        </div>
    );
}

export default App;