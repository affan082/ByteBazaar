import React, { useState } from "react";
import Carousel from "react-bootstrap/Carousel";
import { CarouselItem } from "react-bootstrap";
import "./carousel.css";

// interface CarouselDataItem {
//   id: string | number;
//   [key: string]: any; // This allows flexibility in data fields
// }

interface CustomCarouselProps<Q, T> {
  query: Q;
  TemplateComponent: React.ComponentType<T>; //Does the T Represent The Template Componenet or the Props
  activeIndex?: number;
  onSelect?: (selectedIndex: number) => void;
  controls?: boolean;
  indicators?: boolean;
  variant?: "dark";
  className?: string;
  show?: number;
}

function CustomCarousel<Q, T>({
  TemplateComponent,
  activeIndex = 0,
  onSelect,
  controls = true,
  indicators = true,
  variant = "dark",
  className = "",
  show = 1,
}: CustomCarouselProps<Q, T>) {
  const [index, setIndex] = useState(activeIndex);
  const [data, setData] = useState(new Array<Q>());

  const handleSelect = (selectedIndex: number) => {
    setIndex(selectedIndex);
    if (onSelect) {
      onSelect(selectedIndex);
    }
  };

  return (
    <Carousel
      activeIndex={index}
      onSelect={handleSelect}
      controls={controls}
      indicators={indicators}
      variant={variant}
      className={`custom-carousel ${className}`}
    >
      {data.map((item: Q) => (
        <CarouselItem key={item.id}>
          <TemplateComponent {...item} />
        </CarouselItem>
      ))}
    </Carousel>
  );
}

export default CustomCarousel;
